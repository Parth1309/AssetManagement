sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageBox'
], function(Controller, JSONModel, MessageBox) {
	"use strict";
	var that;
	return Controller.extend("com.damDigitalAssetManagement.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.damDigitalAssetManagement.view.Detail
		 */
		onInit: function() {
			that = this; //Storing the reference of this controller in global variable that
			this.oModel = new JSONModel(); //Creating new JSON Model to be binded with Detail view.
			this.getView().setModel(this.oModel, "AssetDetails"); //Named Model
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRoutePatternMatched(this.onRouteMatched, this);
		},

		//Called everytime Detail View is loaded from the Main View.
		onRouteMatched: function(e) {
			if (e.getParameter("arguments").asset !== undefined) {
				this.Context = e.getParameter("arguments").asset; //Getting the Asset ID from the URL 
				var oModel = this.getView().getModel("AssetDetails");
				var data = this.getOwnerComponent().getModel("oGlobalModel").getData().ProductCollection; //Calling the Global Model to read the data
				var i;
				for (i = 0; i < data.length; i++) {
					if (data[i].AssetID === this.Context) {
						oModel.setProperty("/AssetID", data[i].AssetID);
						oModel.setProperty("/AssetName", data[i].AssetName);
						oModel.setProperty("/AssetDesc", data[i].AssetDesc);
						oModel.setProperty("/AssetType", data[i].AssetType);
						oModel.setProperty("/Theme", data[i].Theme);
						oModel.setProperty("/SKU", data[i].SKU);
						oModel.setProperty("/Campaign", data[i].Campaign);
						oModel.setProperty("/Audience", data[i].Audience);
						oModel.setProperty("/SubAudience", data[i].SubAudience);
						oModel.setProperty("/Market", data[i].Market);
						oModel.setProperty("/ContentManager", data[i].ContentManager);
						oModel.setProperty("/ProductionStatus", data[i].ProdStatus);
						oModel.setProperty("/ReadyDate", data[i].ReadyDate);
						oModel.setProperty("/AssetPortalLink", data[i].ProductPicUrl);
						oModel.refresh();
						break;
					} else continue;
				}

			}
		},
		//Called on click on Edit Button
		onEditPress: function() {
			this.getView().byId("select").setEditable(true);
		},

		//Called on click of Save Button
		onPressButtonSave: function() {
			MessageBox.success("Asset Information Saved Successfully.", {
				actions: [MessageBox.Action.OK],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function(sAction) {
					that.oRouter.navTo("main");
				}
			});
		}

	});
});