sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	'sap/m/Label',
	'sap/ui/model/Filter',
	'com/damDigitalAssetManagement/util/formatter'
], function(Controller, JSONModel, Label, Filter, formatter) {
	"use strict";

	return Controller.extend("com.damDigitalAssetManagement.controller.Main", {
		formatter: formatter,

		//Called once the Main View is loaded.
		onInit: function() {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel("oGlobalModel"); //Getting the global model defined at Manifest.json
			this.oModel.loadData(sap.ui.require.toUrl("com/damDigitalAssetManagement/model.json"), null, false); //Loading the data from model.json file
			this.getView().setModel(this.oModel); //Setting the Global Model to Main View.
			this.aKeys = [
				"AssetID", "ProdStatus", "Market"
			];
			this.oSelectAsset = this.getSelect("slAssets");
			this.oSelectProdStatus = this.getSelect("slProdStatus");
			this.oSelectMarket = this.getSelect("slMarket");
			this.oModel.setProperty("/Filter/text", "Filtered by None");
			this.addSnappedLabel();

			var oFB = this.getView().byId("filterbar");
			if (oFB) {
				oFB.variantsInitialized();
			}
		},

		//Common Getter Function to return the ID of the control
		getSelect: function(sId) {
			return this.getView().byId(sId);
		},

		//Called from onInit lifecycle method, use to add the Label on the Filter bar
		addSnappedLabel: function() {
			var oSnappedLabel = this.getSnappedLabel();
			oSnappedLabel.attachBrowserEvent("click", this.onToggleHeader, this);
			this.getPageTitle().addSnappedContent(oSnappedLabel);
		},
		//Getter function to get the text for Snapped Label
		getSnappedLabel: function() {
			return new Label({
				text: "{/Filter/text}"
			});
		},
		//Getter function to get the Title of the Page
		getPageTitle: function() {
			return this.getPage().getTitle();
		},

		//Getter function to get the reference of the Dynamic Page
		getPage: function() {
			return this.getView().byId("dynamicPageId");
		},

		// Prepare Filters - Called when any of the filters get changed from the Filter Bar
		onSelectChange: function() {
			var aCurrentFilterValues = [];
			aCurrentFilterValues.push(this.getSelectedItemText(this.oSelectAsset));
			aCurrentFilterValues.push(this.getSelectedItemText(this.oSelectProdStatus));
			aCurrentFilterValues.push(this.getSelectedItemText(this.oSelectMarket));
			this.filterTable(aCurrentFilterValues);
		},

		//Get Key of Selected Item
		getSelectedItemText: function(oSelect) {
			return oSelect.getSelectedItem() ? oSelect.getSelectedItem().getKey() : "";
		},

		//Filter the table based on the selected filters
		filterTable: function(aCurrentFilterValues) {
			this.getTableItems().filter(this.getFilters(aCurrentFilterValues));
			this.updateFilterCriterias(this.getFilterCriteria(aCurrentFilterValues));
		},

		//Getter function to get all the filters
		getFilters: function(aCurrentFilterValues) {
			this.aFilters = [];
			this.aFilters = this.aKeys.map(function(sCriteria, i) {
				return new Filter(sCriteria, sap.ui.model.FilterOperator.Contains, aCurrentFilterValues[i]);
			});
			return this.aFilters;
		},
		//Getter function to get all the items binded to the table
		getTableItems: function() {
			return this.getTable().getBinding("items");
		},
		//Getter function to get the reference of the Table
		getTable: function() {
			return this.getView().byId("idAssetTable");
		},
		//Getting filter Criteria
		getFilterCriteria: function(aCurrentFilterValues) {
			return this.aKeys.filter(function(el, i) {
				if (aCurrentFilterValues[i] !== "") {
					return el;
				}
			});
		},

		// Called when Filter criterias are updated.
		updateFilterCriterias: function(aFilterCriterias) {
			this.removeSnappedLabel(); /* because in case of label with an empty text, */
			this.addSnappedLabel(); /* a space for the snapped content will be allocated and can lead to title misalignment */
			this.oModel.setProperty("/Filter/text", this.getFormattedSummaryText(aFilterCriterias));
		},
		// To remove the snapped label (called from updateFilterCriterias function)
		removeSnappedLabel: function() {
			this.getPageTitle().destroySnappedContent();
		},

		getFormattedSummaryText: function(aFilterCriterias) {
			if (aFilterCriterias.length > 0) {
				return "Filtered By (" + aFilterCriterias.length + "): " + aFilterCriterias.join(", ");
			} else {
				return "Filtered by None";
			}
		},
		//Called once Item of the table is clicked, navigate to second View
		onItemPress: function(oEvent) {
			var assetID = oEvent.getSource().getBindingContext().getObject().AssetID;
			this.oRouter.navTo("detail", {
				asset: assetID
			});

		}

	});
});