sap.ui.define([],
	function() {
		"use strict";
		return {
			status: function(sStatus) {
				switch (sStatus) {
					case "Done":
						return "Success";
					case "On Hold":
						return "Error";
					case "In Progress":
						return "Warning";
					default:
						return "None";
				}
			}
		};
	});